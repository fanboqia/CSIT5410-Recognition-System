inputs = [1,2,3];
for i = 1:length(inputs)
    %%%% read the input images %%%%
    img_name = ['hough_',num2str(inputs(i)), '.JPG'];
    img = imread(img_name);
    
    %%%% pre-processing %%%%
    %%%% you can change this part to fit your implementation %%%%
    preproc_img = rgb2gray(img);
    [M ,N] = size(preproc_img);
    preproc_img = imgaussfilt(preproc_img,12);
    
    %%%% to-do 1: edge extraction. %%%%   
    
    edge_img = 

    %%%% to-do 2: Hough transform to find 4 sides of the paper %%%% 
    
    lines = 
     
    
    %%%% plot four green lines on the input image %%%%
    %%%% you can change this part to fit your implementation %%%%
    figure, imshow(img), hold on
    for k = 1:length(lines)
       xy = [lines(k).point1; lines(k).point2];
       plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');      
    end
end





  