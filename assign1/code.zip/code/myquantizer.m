% myquantizer takes a gray image and a target number of gray levels as input, 
% and generates the quantized image as output ;
%
%   output_img = myquantizer(img, level) computes the quantized image
%   output_img from the input image img, level indicates the gray level of
%   the quantized image
%   
% The function prototype is “myquantizer(input_img, level) → output_img”, 
% where “level” is an integer in [0, 255] defining the number of gray levels of output, 
% “input_img” is an image with 256 gray levels. 
% Note that, computers always represent “white” via the pixel value of 255(for uint8). 
% For example, when “level” == 4, the resulting image should contain pixels of {0, 85, 170, 255}, 
% instead of {0, 1, 2, 3}.

function output_img = myquantizer(img, level)
