% myscaler takes a gray image and a target size as input, and generates the scaled image as output
%
%   output_img = myscaler(img, output_size) computes the rescaled image output_img
%   from the input image img, output_size indicates the new size
%
% The function prototype is “myscaler(img, output_size) → output_img”, 
% where 'img' and 'output_img' are two-dimensional matrices storing images, 
% and 'output_size' is a tuple of (width, height) defining the spatial resolution of output.

function output_img = myscaler(img, output_size)